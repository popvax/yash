# Clinical reports

Yash's clinical reports are included here as PDFs. Clone the repository to get
all four, or open and download an individual report using the links below.
These are source clinical records; they are separate from our research predictions.

| Report | Date | Contents |
|---|---|---|
| [Stanford liver biopsy and IHC](stanford-pathology-ihc-2025-01.pdf) | Specimen 15 January 2025; pathology signed 17 January, addendum 21 January | Liver pathology, diagnostic IHC and Claudin-18.2 addendum |
| [Stanford STAMP tumour genetic testing](stanford-stamp-2025-01-31.pdf) | Approved 31 January 2025 | Tumour DNA panel and molecular findings from the liver biopsy |
| [Caris tumour profiling](caris-tissue-2025-02-22.pdf) | Reported 22 February 2025; specimen 15 January | Liver-tissue DNA/RNA profiling, fusion, predicted HLA types and IHC |
| [Guardant360 liquid biopsy](guardant360-2025-10-21.pdf) | Reported 21 October 2025; blood collected 14 October | cfDNA findings, HLA class I and longitudinal results |

STAMP and Caris are tumour genetic tests. Neither is a separate inherited/germline
genetic-testing report.

## Sources and integrity

The Stanford pathology/IHC PDF copies physical pages **6-8** of the supplied
42-page combined clinical PDF. STAMP copies pages **17-19**. Page content, original
pagination and signatures printed on the pages are preserved; no report text is
rewritten. Every extracted page was rendered and compared pixel for pixel with
its source page. Caris and Guardant are the complete original PDFs fetched from
the inventoried Drive files, copied byte for byte.

[manifest.json](manifest.json) records source filenames, Drive links, source-page
mapping, report/specimen dates, sizes, SHA-256 hashes and repository paths.
