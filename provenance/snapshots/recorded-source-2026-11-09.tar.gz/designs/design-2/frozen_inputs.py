"""Package only the recorded evidence reused by the new selection branch."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import gzip


def package(repo,output):
    repo=Path(repo);output=Path(output);output.mkdir(parents=True,exist_ok=True)
    names=[
        'config/case.json','config/linkers.json','data/checkpoints/manifest.json',
        'data/checkpoints/lens-scored-windows.tsv.gz','data/checkpoints/target-occurrences.tsv.gz',
        'data/checkpoints/provenance/construct-inference.json','data/checkpoints/provenance/construct-model-files.json',
        'data/splice-evidence/normal-screen/all-windows.tsv.gz',
        'data/splice-evidence/normal-screen/summary.json',
        'data/splice-evidence/normal-screen/selection-policy.json',
        'data/splice-evidence/normal-screen/normal-receipt.json',
        'data/splice-evidence/normal-screen/strand-receipt.json',
        'data/splice-evidence/scoring/affinities.tsv.gz',
        'data/fusion-evidence/inframe-request.json','data/fusion-evidence/inframe-selection.json',
        'data/fusion-evidence/inframe-binding-review.json',
        'designs/initial/selection/selected.tsv',
        'designs/initial/construct/architecture.json',
        'designs/initial/construct/allele-evidence/read-evidence.json',
        'designs/initial/construct/allele-evidence/typing-comparison.json',
    ]
    # These helpers are reused unchanged, with hashes, rather than silently
    # replacing the recorded design's frozen inputs or case context.
    names += [str(p.relative_to(repo)) for p in sorted((repo/'src/yash_vaccine').rglob('*.py'))]
    names += [str(p.relative_to(repo)) for p in sorted((repo/'designs/initial/construct').glob('*.py'))]
    names += [str(p.relative_to(repo)) for p in sorted((repo/'designs/initial/construct/mrna').iterdir())
              if p.is_file() and (p.suffix=='.py' or p.name in ['backbone.json','annotation-sources.json','human-codon-usage.json','requirements.txt'])]
    paths=[repo/name for name in names]
    meta=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
              files={name:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in zip(names,paths)})
    manifest=output/'frozen-inputs.json'
    archive=output/'frozen-inputs.tar.gz'
    if manifest.exists() and archive.exists():
        # Preserve exact uploaded bytes on resume; gzip timestamps must not
        # turn unchanged evidence into a spurious immutable-input conflict.
        recorded=json.loads(manifest.read_text())
        assert recorded['files']==meta['files'],'Frozen scientific inputs changed; use a separate run root'
        with tarfile.open(archive) as tar:
            assert {m.name for m in tar.getmembers()}==set(recorded['files'])
            for member in tar.getmembers():
                assert member.isfile()
                with tar.extractfile(member) as stream:
                    assert hashlib.sha256(stream.read()).hexdigest()==recorded['files'][member.name]['sha256']
        return [manifest,archive]
    assert not manifest.exists() and not archive.exists(),'Inspect incomplete frozen-input packaging before retry'
    with archive.open('wb') as raw, gzip.GzipFile(filename='',mode='wb',mtime=0,fileobj=raw) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,path in zip(names,paths):
                info=tarfile.TarInfo(name);info.size=path.stat().st_size
                info.mtime=0;info.mode=0o644;info.uid=info.gid=0
                with path.open('rb') as stream:tar.addfile(info,stream)
    manifest.write_text(json.dumps(meta,indent=2)+'\n')
    return [manifest,archive]
